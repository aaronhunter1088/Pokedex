package pokedex.services;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import skaro.pokeapi.resource.pokemon.Pokemon;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Cacheable(value = "pokemonCache", key = "'pokemonMap'")
@Service
public class PokemonCacheService
{
    private final Map<Integer, Pokemon> pokemonMap = new ConcurrentHashMap<>();

    public Map<Integer, Pokemon> getPokemonMap()
    {
        return pokemonMap;
    }

    public void addToCache(Map<Integer, Pokemon> pokemonEntries)
    {
        if (pokemonEntries == null || pokemonEntries.isEmpty()) {
            return;
        }
        pokemonMap.putAll(pokemonEntries);
    }

    public void clearPokemonMap()
    {
        pokemonMap.clear();
    }
}
